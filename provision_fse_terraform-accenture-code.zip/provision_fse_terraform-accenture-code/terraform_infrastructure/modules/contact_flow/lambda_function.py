import json
import boto3
import os
import logging

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

dynamodb = boto3.resource('dynamodb')
table_name = os.environ.get('DYNAMODB_TABLE_NAME')
table = dynamodb.Table(table_name)

def lambda_handler(event, context):
    logger.info(f"Received event: {json.dumps(event)}")
    try:
         # Extract FlowName
         flow_name = event.get('Details', {}).get('Parameters', {}).get('FlowName')
         if not flow_name:
             raise ValueError("Missing 'FlowName' in event.Details.Parameters input.") 
         logger.info(f"Fetching prompts for flow: {flow_name}")

         # Get item from DynamoDB
         response = table.get_item(Key={'FlowName': flow_name})
         item = response.get('Item')

         if not item or 'Prompts' not in item:
             raise KeyError(f"No prompts found for flow '{  flow_name}'") 
         prompts = json.loads(item['Prompts']) if isinstance(item['Prompts'], str) else item['Prompts']
         logger.info(f"Prompts retrieved: {prompts}")

         # Return prompts at root level with Success status
         return {
            'statusCode': 'Success',
             **prompts
         }
    except Exception as e:
         logger.error(f"Error occurred: {str(e)}", exc_info=True)
         return {
             'statusCode': 'Error',
             'error': str(e)
         }


       
