# s3_lifecycle

This is a module to apply the correct licecycle policies to the "telephony" S3 bucket.


## Variables

The following variables are accepted :

|Variable|Default|Required|Description|
|----|----|----|----|
|environment||Yes|The "environment" we are deploying to. Used for naming resources.|
|project|"inf"|No|The "project". Used for naming resources.|


## Outputs

This module currently does not have any outputs.

